# Maré – como gerar o APK

Não precisa instalar nada no computador. O GitHub compila o APK para você.

1. Crie uma conta gratuita em github.com e um repositório novo (pode ser privado).
2. Envie todo o conteúdo desta pasta para o repositório (inclusive a pasta oculta `.github`).
   Dica: no GitHub, use "Add file > Upload files" e arraste a pasta inteira.
3. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow**.
4. Em cerca de 5 minutos, abra a execução concluída e baixe **mare-apk** (em Artifacts).
5. Descompacte, envie o `app-debug.apk` para o celular e instale.
   O Android vai pedir para permitir instalação de fontes desconhecidas.

## Observações
- Esse APK é de teste (debug). Para publicar na Play Store, é preciso gerar um pacote assinado (AAB).
- Para cobrar assinaturas dentro do app na Play Store, a Google exige o Google Play Billing.
- As fontes vêm da internet; sem conexão o app usa a fonte padrão do celular.
